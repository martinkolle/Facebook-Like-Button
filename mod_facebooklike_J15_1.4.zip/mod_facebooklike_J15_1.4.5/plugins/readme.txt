WHAT IS THIS?
This is a plugin for Joomla, where you can use the integrated open graph..